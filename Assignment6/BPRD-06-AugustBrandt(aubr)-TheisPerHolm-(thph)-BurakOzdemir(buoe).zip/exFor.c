void main(int n) {
    int i;
    for (i = 0; i < n; i = i + 1) {
        print i;
        println;
    }
}